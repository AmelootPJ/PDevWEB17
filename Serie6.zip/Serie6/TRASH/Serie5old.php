<?php 
	$Montitle= 'Mon Title 2';
	require 'haut.php' ;
?>
	<div class="container-fluid">
		<div class="row">
			<header id="header" class="col-lg-10 offset-3">
				<h1>Série 3 : Exercices sur les boucles</h1>
			</header>	
		</div>
	</div>
	<div class="container">
		
		<div class="row">
			<section class="col-lg-10">
				<div class="row">
					<article class="col-sm-6">
						<h2>Exercice 1</h2>
							<table class="table">
									<?PHP include ('...\Functions\Loop.php')
							</table>
					</article>
					<article class="col-sm-6">
						<h2>Exercice 2</h2>
							<table class="table">

							</table>
					</article>
					<article class="col-sm-6">
						<h2>Exercice 3</h2>
						<table class="table">
							<tr>
								
							</tr>
						</table>
					</article>
				</div>
			</section>
			<aside class="col-lg-2">
			</aside>
		</div>
	</div>
<?php 
	require 'bas.php' ;
?>
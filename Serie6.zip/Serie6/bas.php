
	<div class="container-fluid">
		<div class="row">
			<footer class="col-lg-12">
				Fait par DE GUGLIELMO Roberto 
				<a href="#haut" >haut de page</a>
			</footer>
		</div>
		
	</div>
</body>
</html>
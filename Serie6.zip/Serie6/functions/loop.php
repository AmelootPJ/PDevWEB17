<?php


		function LoopI($Str, $I)
		{

				echo $Str . $I
		}


	



?>
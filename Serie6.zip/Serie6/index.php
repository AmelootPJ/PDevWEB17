<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" id="min-width" lang="fr" xml:lang="fr" xmlns:og="http://opengraphprotocol.org/schema/"  >
<?PHP

include ('page1.php');

?>
<html>
		<meta http-equiv="Content-LANGUAGE" content="French" />
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<meta name="GENERATOR" content="PHP Designer 2005" />
		<meta http-equiv="Content-Script-Type" content="text/javascript" />
		<meta http-equiv="Content-Style-Type" content="text/ccs" />
		<meta name="author" content="Pierre-Jean Ameloot" />
		<meta charset="utf-8" />




<footer>
	<p><a href="#">Nopseudonline@gmail.com</a></p>
</footer>
</html>